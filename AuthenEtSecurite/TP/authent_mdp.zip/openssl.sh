#!/bin/sh
openssl passwd -1 -salt SALT mdp
