#!/bin/sh
#python -m SimpleHTTPServer
ip a
python3 -m http.server
